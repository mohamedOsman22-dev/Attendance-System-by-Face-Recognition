# import re
import mediapipe as mp
import csv
from sys import path
from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
import os
import cv2
import numpy as np
from tkinter import messagebox
from time import strftime
from datetime import datetime 

 


# مهم جدًا لحل مشكلة الـ DLL في OpenCV
os.add_dll_directory(os.path.dirname(cv2.__file__))
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

class Face_Recognition:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1366x768+0+0")
        self.root.title("Face Recognition Pannel")

        # تأكد من وجود المجلدات
        os.makedirs("data_img", exist_ok=True)
        # الحصول على أبعاد الشاشة تلقائيًا
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # تحميل وتعديل حجم صورة البانر لتناسب عرض الشاشة
        img = Image.open(os.path.join(os.path.dirname(__file__), "Images_GUI/banner.jpg"))
        banner_height = int(screen_height * 0.15)  # 15% من الشاشة
        img = img.resize((screen_width, banner_height), Image.Resampling.LANCZOS)
        self.photoimg = ImageTk.PhotoImage(img)

        # تعيين صورة البانر
        f_lb1 = Label(self.root, image=self.photoimg)
        f_lb1.place(x=0, y=0, width=screen_width, height=banner_height)

        # تحميل وتعديل صورة الخلفية لتناسب كل الشاشة
        bg1 = Image.open(os.path.join(os.path.dirname(__file__), "Images_GUI/t_bg1.jpg"))
        bg1 = bg1.resize((screen_width, screen_height), Image.Resampling.LANCZOS)
        self.photobg1 = ImageTk.PhotoImage(bg1)

        # تعيين صورة الخلفية
        bg_img = Label(self.root, image=self.photobg1)
        bg_img.place(x=0, y=banner_height, width=screen_width, height=screen_height - banner_height)


        #title section
        title_lb1 = Label(bg_img,text="Welcome to Face Recognition Pannel",font=("verdana",30,"bold"),bg="white",fg="navyblue")
        title_lb1.place(relx=0, rely=0, relwidth=1, relheight=0.06)


        # Create buttons below the section 
        # ------------------------------------------------------------------------------------------------------------------- 
        # Training button 1
        std_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/f_det.jpg"))
        std_img_btn=std_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.std_img1=ImageTk.PhotoImage(std_img_btn)

        std_b1 = Button(bg_img,command=self.face_recog,image=self.std_img1,cursor="hand2")
        std_b1.place(x=600,y=170,width=180,height=180)

        std_b1_1 = Button(bg_img,command=self.face_recog,text="Face Detector",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        std_b1_1.place(x=600,y=350,width=180,height=45)
    #=====================Attendance===================

 

    def mark_attendance(self, std_id, name, Corse):
        file_path = "attendance.csv"
        today = datetime.now().strftime("%d-%m-%Y")
        time_now = datetime.now().strftime("%I:%M %p")

        # إنشاء الملف إذا لم يكن موجودًا أو فاضي
        file_is_empty = not os.path.exists(file_path) or os.stat(file_path).st_size == 0
        if file_is_empty:
            with open(file_path, 'w', newline='', encoding="utf-8") as file:
                writer = csv.writer(file)
                writer.writerow(["std_id", "std_name", "Corse", "std_time", "std_date", "std_attendance"])

        # التحقق من تكرار تسجيل الحضور
        attendance_exists = False
        with open(file_path, 'r', encoding="utf-8") as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row["std_id"] == std_id and row["std_date"] == today:
                    attendance_exists = True
                    break

        # إضافة الحضور لو مش متسجل
        if not attendance_exists:
            with open(file_path, 'a', newline='', encoding="utf-8") as file:
                writer = csv.writer(file)
                writer.writerow([std_id, name, Corse, time_now, today, "Present"])


    #================face recognition==================

 

    def face_recog(self):
        

        def load_students_from_csv():
            students = []
            if os.path.exists("students.csv"):
                with open("students.csv", mode="r", encoding="utf-8") as file:
                    reader = csv.DictReader(file)
                    for row in reader:
                        students.append(row)
            return students

        def draw_boundary_with_mediapipe(img, clf):
            mp_face_detection = mp.solutions.face_detection
            mp_drawing = mp.solutions.drawing_utils

            rgb_image = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            results = None

            with mp_face_detection.FaceDetection(model_selection=1, min_detection_confidence=0.3) as face_detection:
                results = face_detection.process(rgb_image)

                if results.detections:
                    for detection in results.detections:
                        bboxC = detection.location_data.relative_bounding_box
                        ih, iw, _ = img.shape
                        x = int(bboxC.xmin * iw)
                        y = int(bboxC.ymin * ih)
                        w = int(bboxC.width * iw)
                        h = int(bboxC.height * ih)

                        x, y = max(0, x), max(0, y)
                        w, h = min(iw - x, w), min(ih - y, h)

                        id, predict = clf.predict(gray_image[y:y + h, x:x + w])
                        confidence = int((100 * (1 - predict / 300)))

                        students = load_students_from_csv()
                        student_name = ""
                        student_id = ""
                        student_course = ""

                        for student in students:
                            if int(student['Student_ID']) == id:
                                student_name = student['Name']
                                student_course = student['Course']
                                student_id = student['Student_ID']
                                break

                        if confidence > 77 and student_id != "":
                            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
                            cv2.putText(img, f"ID:{student_id}", (x, y - 60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                            cv2.putText(img, f"Name:{student_name}", (x, y - 35), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                        #   cv2.putText(img, f"Roll:{student_roll}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                            self.mark_attendance(student_id, student_name, student_course)

                        else:
                            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
                            cv2.putText(img, "Unknown", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

            return img

        # تأكد من وجود البيانات
        if not os.path.exists("students.csv"):
            messagebox.showerror("خطأ", "ملف الطلاب students.csv غير موجود. الرجاء تسجيل الطلاب أولاً.", parent=self.root)
            return

        if not os.path.exists("clf.xml"):
            messagebox.showerror("خطأ", "ملف التصنيف clf.xml غير موجود. الرجاء تدريب النموذج أولاً.", parent=self.root)
            return

        clf = cv2.face.LBPHFaceRecognizer_create()
        clf.read("clf.xml")

        videoCap = cv2.VideoCapture(0)
        if not videoCap.isOpened():
            messagebox.showerror("Error", "فشل في فتح الكاميرا. تأكد أنها متصلة بشكل صحيح.", parent=self.root)
            return

        # اجعل النافذة قابلة للتكبير والتصغير
        cv2.namedWindow("Face Recognition", cv2.WINDOW_NORMAL)

        # ضبط الحجم المبدئي للنافذة (مثلاً 640x480)
        cv2.resizeWindow("Face Recognition", 640, 480)

        while True:
            ret, img = videoCap.read()
            if not ret:
                break

            img = cv2.resize(img, None, fx=2.6, fy=2.6)

            img = draw_boundary_with_mediapipe(img, clf)
            cv2.imshow("Face Recognition", img)

            if cv2.waitKey(1) == 13 or cv2.getWindowProperty("Face Recognition", cv2.WND_PROP_VISIBLE) < 1:
                break

        videoCap.release()
        cv2.destroyAllWindows()




if __name__ == "__main__":
    root=Tk()
    obj=Face_Recognition(root)
    root.mainloop()