import re
from tkinter import* 
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
# --------------------------
from train import Train
from student import Student
from train import Train
from face_recognition import Face_Recognition
from attendance import Attendance
import csv
import os
import cv2
import sys

# دعم المسارات سواء شغال كـ EXE أو سكريبت
def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS  # لما يكون EXE
    except Exception:
        base_path = os.path.abspath(".")  # لما يكون سكريبت عادي
    return os.path.join(base_path, relative_path)

# مهم جدًا لحل مشكلة الـ DLL في OpenCV
os.add_dll_directory(os.path.dirname(cv2.__file__))
import tkinter as tk
import time

# نافذة الشاشة المؤقتة
splash_root = tk.Tk()
splash_root.overrideredirect(True)  # إزالة الإطار
splash_root.geometry("400x300+500+200")  # المقاس والمكان

splash_img = Image.open(resource_path("Images_GUI/splash.png"))
splash_photo = ImageTk.PhotoImage(splash_img)

label = tk.Label(splash_root, image=splash_photo)
label.pack()

# إغلاق الشاشة بعد 3 ثوانٍ وفتح البرنامج الأساسي
def close_splash():
    splash_root.destroy()

splash_root.after(3000, close_splash)
splash_root.mainloop()

class Login:
    def __init__(self,root):
        self.root=root
        self.root.title("Login")
        self.root.geometry("1366x768+0+0")

        # variables 
        self.username_var = StringVar()
        self.password_var = StringVar()
        self.var_ssq=StringVar()
        self.var_sa=StringVar()
        self.var_pwd=StringVar()

        self.bg = ImageTk.PhotoImage(file=os.path.join(os.path.dirname(__file__), "Images_GUI/loginBg1.jpg"))
        
        lb1_bg=Label(self.root,image=self.bg)
        lb1_bg.place(x=0,y=0, relwidth=1,relheight=1)

        frame1= Frame(self.root,bg="#002B53")
        frame1.place(x=560,y=170,width=340,height=450)
        
        img1=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/log1.png"))
        img1=img1.resize((100,100),Image.Resampling.LANCZOS)
        self.photoimage1=ImageTk.PhotoImage(img1)
        lb1img1 = Label(image=self.photoimage1,bg="#002B53")
        lb1img1.place(x=690,y=175, width=100,height=100)

        get_str = Label(frame1,text="Login",font=("times new roman",20,"bold"),fg="white",bg="#002B53")
        get_str.place(x=140,y=100)

        #label1 
        username =lb1= Label(frame1,text="Username:",font=("times new roman",15,"bold"),fg="white",bg="#002B53")
        username.place(x=30,y=160)

        #entry1 
        self.txtuser=ttk.Entry(frame1,font=("times new roman",15,"bold"))
        self.txtuser.place(x=33,y=190,width=270)


        #label2 
        pwd =lb1= Label(frame1,text="Password:",font=("times new roman",15,"bold"),fg="white",bg="#002B53")
        pwd.place(x=30,y=230)

        #entry2 
        self.txtpwd=ttk.Entry(frame1,show="*",font=("times new roman",15,"bold"))
        self.txtpwd.place(x=33,y=260,width=270)


        # Creating Button Login
        loginbtn=Button(frame1,command=self.login,text="Login",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="#002B53",bg="white",activeforeground="white",activebackground="#007ACC")
        loginbtn.place(x=33,y=320,width=270,height=35)


        # Creating Button Registration
        loginbtn=Button(frame1,command=self.reg,text="Register",font=("times new roman",10,"bold"),bd=0,relief=RIDGE,fg="white",bg="#002B53",activeforeground="orange",activebackground="#002B53")
        loginbtn.place(x=33,y=370,width=50,height=20)


        # Creating Button Forget
        loginbtn=Button(frame1,command=self.forget_pwd,text="Forget",font=("times new roman",10,"bold"),bd=0,relief=RIDGE,fg="white",bg="#002B53",activeforeground="orange",activebackground="#002B53")
        loginbtn.place(x=90,y=370,width=50,height=20)


    #  THis function is for open register window
    def reg(self):
        self.new_window=Toplevel(self.root)
        self.app=Register(self.new_window)
    def toggle_password(self):
        if self.show_password:
            self.new_pwd.config(show="*")  # اخفي الباسورد
            self.btn_toggle_password.config(text="👁️")  
            self.show_password = False
        else:
            self.new_pwd.config(show="")  # أظهر الباسورد
            self.btn_toggle_password.config(text="🙈")  
            self.show_password = True

        
    def login(self):
    # تحقق من وجود ملف users.csv، وإذا مش موجود أنشئه مع الأعمدة
        if not os.path.exists("users.csv"):
            with open("users.csv", mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['Email', 'Password','First Name'])  # الأعمدة الأساسية

        # ⛔ خُد القيم هنا مباشرة قبل أي destroy
        email = self.txtuser.get()
        password = self.txtpwd.get()

        if email == "" or password == "":
            messagebox.showerror("Error", "All fields are required!")
            return

        # ⛔ كده نقدر نستخدمهم بعدين بدون استدعاء .get()
        if email == "admin" and password == "admin":
            messagebox.showinfo("Successfully", "Welcome to Attendance Management System Using Facial Recognition")
            
            # اغلق النافذة بعد أخذ القيم
            self.root.destroy()

            # افتح الصفحة الرئيسية
            main = Tk()
            main.title("Main Page")
            main.geometry("1366x768+0+0")
            self.app = Face_Recognition_System(main, "Admin")
            main.mainloop()
            return  # مهم علشان ميدخلش في الشرط اللي بعده

        # تحقق من ملف المستخدمين
        found = False
        username = ""

        with open("users.csv", mode='r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row["Email"] == email and row["Password"] == password:
                    found = True
                    username = row["First Name"]
                    break

        if not found:
            messagebox.showerror("Error", "Invalid Username or Password!")
        else:
            open_min = messagebox.askyesno("Access", "Access only Admin. Continue?")
            if open_min:
                self.root.destroy()
                main = Tk()
                main.title("Main Page")
                main.geometry("1366x768+0+0")
                self.app = Face_Recognition_System(main, username)
                main.mainloop()
            else:
                return


                

#=======================Reset Passowrd Function=============================
    def reset_pass(self):
        if self.var_ssq.get() == "Select":
            messagebox.showerror("Error", "Select the Security Question!", parent=self.root2)
        elif self.var_sa.get() == "":
            messagebox.showerror("Error", "Please Enter the Answer!", parent=self.root2)
        elif self.var_pwd.get() == "":
            messagebox.showerror("Error", "Please Enter the New Password!", parent=self.root2)
        else:
            try:
                # قراءة بيانات المستخدم من ملف CSV
                user_found = False
                updated_rows = []

                with open('users.csv', mode='r', newline='', encoding='utf-8') as file:
                    reader = csv.DictReader(file)
                    for row in reader:
                        if row["Email"] == self.txtuser.get() and row["Security Question"] == self.var_ssq.get() and row["Security Answer"] == self.var_sa.get():
                            user_found = True
                            # تحديث كلمة المرور
                            row["Password"] = self.var_pwd.get()
                        updated_rows.append(row)

                if not user_found:
                    messagebox.showerror("Error", "Incorrect Security Answer or Email!", parent=self.root2)
                else:
                    # إعادة كتابة البيانات إلى ملف CSV مع تحديث كلمة المرور
                    with open('users.csv', mode='w', newline='', encoding='utf-8') as file:
                        fieldnames = ["First Name", "Last Name", "Contact Number", "Email", "Security Question", "Security Answer", "Password"]
                        writer = csv.DictWriter(file, fieldnames=fieldnames)
                        writer.writeheader()  # كتابة العناوين
                        writer.writerows(updated_rows)  # كتابة البيانات بعد التحديث

                    messagebox.showinfo("Info", "Password successfully updated. Please login with your new password.", parent=self.root2)

                    self.root2.destroy()  # يقفل نافذة Reset Password
                    self.root.destroy()   # يقفل البرنامج كله
                # فتح نافذة Login جديدة
                import subprocess
                subprocess.Popen(["python", "login.py"])  # <-- هنا اسم ملف login بتاعك

                     
            except Exception as es:
                messagebox.showerror("Error", f"An error occurred: {str(es)}", parent=self.root2)
            


# =====================Forget window=========================================
    def forget_pwd(self):
        if self.txtuser.get() == "":
            messagebox.showerror("Error", "Please Enter the Email ID to reset Password!")
        else:
            email = self.txtuser.get()

            # التحقق من وجود ملف users.csv
            if not os.path.exists("users.csv"):
                messagebox.showerror("Error", "No users registered yet!")
                return

            user_found = False
            rows = []

            # قراءة البيانات من ملف CSV
            with open("users.csv", mode="r", newline="") as file:
                reader = csv.DictReader(file)
                for row in reader:
                    if row["Email"] == email:
                        user_found = True
                        # فتح نافذة جديدة لإعادة تعيين كلمة المرور
                        self.root2 = Toplevel()
                        self.root2.title("Forget Password")
                        self.root2.geometry("400x400+610+170")
                        
                        l = Label(self.root2, text="Forget Password", font=("times new roman", 30, "bold"), fg="#002B53", bg="#fff")
                        l.place(x=0, y=10, relwidth=1)

                        # -------------------fields-------------------
                        #label1
                        ssq = lb1 = Label(self.root2, text="Select Security Question:", font=("times new roman", 15, "bold"), fg="#002B53", bg="#F2F2F2")
                        ssq.place(x=70, y=80)

                        # Combo Box1
                        self.combo_security = ttk.Combobox(self.root2, textvariable=self.var_ssq, font=("times new roman", 15, "bold"), state="readonly")
                        self.combo_security["values"] = ("Select", "Your Date of Birth", "Your Nick Name", "Your Favorite Book")
                        self.combo_security.current(0)
                        self.combo_security.place(x=70, y=110, width=270)

                        # label2
                        sa = lb1 = Label(self.root2, text="Security Answer:", font=("times new roman", 15, "bold"), fg="#002B53", bg="#F2F2F2")
                        sa.place(x=70, y=150)

                        # entry2
                        self.txtpwd = ttk.Entry(self.root2, textvariable=self.var_sa, font=("times new roman", 15, "bold"))
                        self.txtpwd.place(x=70, y=180, width=270)

                        # label2
                        new_pwd = lb1 = Label(self.root2, text="New Password:", font=("times new roman", 15, "bold"), fg="#002B53", bg="#F2F2F2")
                        new_pwd.place(x=70, y=220)

                        # entry2
                        self.new_pwd = ttk.Entry(self.root2, show="*", textvariable=self.var_pwd, font=("times new roman", 15, "bold"))
                        self.new_pwd.place(x=70, y=250, width=230)

                        # Creating Button New Password
                        loginbtn = Button(self.root2, command=self.reset_pass, text="Reset Password", font=("times new roman", 15, "bold"), bd=0, relief=RIDGE, fg="#fff", bg="#002B53", activeforeground="white", activebackground="#007ACC")
                        loginbtn.place(x=70, y=300, width=270, height=35)
                        # زر العين لعرض أو إخفاء كلمة السر
                        self.show_password = False  # متغير للتحكم بالحالة (ظاهر أم مخفي)
                        self.btn_toggle_password = Button(self.root2, text="👁️", command=self.toggle_password,bd=0, bg="#F2F2F2", activebackground="#F2F2F2", font=("times new roman", 12))
                        self.btn_toggle_password.place(x=305, y=250, width=35, height=28)

                        break

                    rows.append(row)

            if not user_found:
                messagebox.showerror("Error", "Please Enter the Valid Email ID!")
           

class Register:
    def __init__(self,root):
        self.root=root
        self.root.title("Register")
        self.root.geometry("1366x768+0+0")
        self.show_password = False

        # ============ Variables =================
        self.var_fname=StringVar()
        self.var_lname=StringVar()
        self.var_cnum=StringVar()
        self.var_email=StringVar()
        self.var_ssq=StringVar()
        self.var_sa=StringVar()
        self.var_pwd=StringVar()
        self.var_cpwd=StringVar()
        self.var_check=IntVar()

        self.bg = ImageTk.PhotoImage(file=os.path.join(os.path.dirname(__file__), "Images_GUI/bgReg.jpg"))

        lb1_bg=Label(self.root,image=self.bg)
        lb1_bg.place(x=0,y=0, relwidth=1,relheight=1)

        frame= Frame(self.root,bg="#F2F2F2")
        frame.place(x=100,y=80,width=900,height=580)
        
        get_str = Label(frame,text="Registration",font=("times new roman",30,"bold"),fg="#002B53",bg="#F2F2F2")
        get_str.place(x=350,y=130)

        #label1 
        fname =lb1= Label(frame,text="First Name:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        fname.place(x=100,y=200)

        #entry1 
        self.txtuser=ttk.Entry(frame,textvariable=self.var_fname,font=("times new roman",15,"bold"))
        self.txtuser.place(x=103,y=225,width=270)


        #label2 
        lname =lb1= Label(frame,text="Last Name:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        lname.place(x=100,y=270)

        #entry2 
        self.txtpwd=ttk.Entry(frame,textvariable=self.var_lname,font=("times new roman",15,"bold"))
        self.txtpwd.place(x=103,y=295,width=270)

        # ==================== section 2 -------- 2nd Columan===================

        #label1 
        cnum =lb1= Label(frame,text="Contact No:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        cnum.place(x=530,y=200)

        #entry1 
        self.txtuser=ttk.Entry(frame,textvariable=self.var_cnum,font=("times new roman",15,"bold"))
        self.txtuser.place(x=533,y=225,width=270)


        #label2 
        email =lb1= Label(frame,text="Email:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        email.place(x=530,y=270)

        #entry2 
        self.txtpwd=ttk.Entry(frame,textvariable=self.var_email,font=("times new roman",15,"bold"))
        self.txtpwd.place(x=533,y=295,width=270)

        # ========================= Section 3 --- 1 Columan=================

        #label1 
        ssq =lb1= Label(frame,text="Select Security Question:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        ssq.place(x=100,y=350)

        #Combo Box1
        self.combo_security = ttk.Combobox(frame,textvariable=self.var_ssq,font=("times new roman",15,"bold"),state="readonly")
        self.combo_security["values"]=("Select","Your Date of Birth","Your Nick Name","Your Favorite Book")
        self.combo_security.current(0)
        self.combo_security.place(x=103,y=375,width=270)


        #label2 
        sa =lb1= Label(frame,text="Security Answer:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        sa.place(x=100,y=420)

        #entry2 
        self.txtpwd=ttk.Entry(frame,textvariable=self.var_sa,font=("times new roman",15,"bold"))
        self.txtpwd.place(x=103,y=445,width=270)

        # ========================= Section 4-----Column 2=============================

        #label1 
        pwd =lb1= Label(frame,text="Password:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        pwd.place(x=530,y=350)

        #entry1 
        self.txtpwd=ttk.Entry(frame,textvariable=self.var_pwd,show="*",font=("times new roman",15,"bold"))
        self.txtpwd.place(x=533,y=375,width=270)


        #label2 
        cpwd =lb1= Label(frame,text="Confirm Password:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        cpwd.place(x=530,y=420)

        #entry2 
        self.txtcpwd=ttk.Entry(frame,textvariable=self.var_cpwd,show="*",font=("times new roman",15,"bold"))
        self.txtcpwd.place(x=533,y=445,width=270)

        # Checkbutton
        checkbtn = Checkbutton(frame,variable=self.var_check,text="I Agree the Terms & Conditions",font=("times new roman",13,"bold"),fg="#002B53",bg="#F2F2F2")
        checkbtn.place(x=100,y=480,width=270)


        # Creating Button Register
        loginbtn=Button(frame,command=self.reg,text="Register",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="#fff",bg="#002B53",activeforeground="white",activebackground="#007ACC")
        loginbtn.place(x=320,y=510,width=270,height=35)

        # Creating Button Login
        loginbtn = Button(frame,command=self.return_login, text="Login", font=("times new roman", 15, "bold"), bd=0, relief=RIDGE, fg="#fff", bg="#002B53", activeforeground="white", activebackground="#007ACC")
        loginbtn.place(x=810, y=510, width=70, height=35)


        self.btn_toggle_password = Button(frame, text="👁️", command=self.toggle_passwords, font=("times new roman", 12), bg="#F2F2F2", bd=0)
        self.btn_toggle_password.place(x=810, y=375, width=40, height=100)

    def toggle_passwords(self):
        if self.show_password:
            self.txtpwd.config(show="*")
            self.txtcpwd.config(show="*")
            self.btn_toggle_password.config(text="👁️")
            self.show_password = False
        else:
            self.txtpwd.config(show="")
            self.txtcpwd.config(show="")
            self.btn_toggle_password.config(text="🙈")
            self.show_password = True

    def reg(self):
    # تحقق من ملء الحقول
        if self.var_fname.get() == "" or self.var_email.get() == "" or self.var_ssq.get() == "Select" or self.var_pwd.get() == "":
            messagebox.showerror("Error", "All Fields Required!", parent=self.root)
            return

        # تحقق من صيغة الإيميل (ينتهي بـ .com فقط)
        email_pattern = r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.com$'
        if not re.match(email_pattern, self.var_email.get()):
            messagebox.showerror("Error", "Invalid email format! Use e.g. user@example.com", parent=self.root)
            return

        # تحقق من صيغة الرقم (أرقام فقط)
        phone_pattern = r'^\d+$'
        if not re.match(phone_pattern, self.var_cnum.get()):
            messagebox.showerror("Error", "Invalid phone number! Please enter numbers only", parent=self.root)
            return

        # تحقق من تطابق الباسورد
        if self.var_pwd.get() != self.var_cpwd.get():
            messagebox.showerror("Error", "Passwords do not match!", parent=self.root)
            return

        # تحقق من الموافقة على الشروط
        if self.var_check.get() == 0:
            messagebox.showerror("Error", "Please agree to the terms and conditions", parent=self.root)
            return

        try:
            file_path = 'users.csv'
            headers = ["First Name", "Last Name", "Contact Number", "Email", "Security Question", "Security Answer", "Password"]

            # تأكد من وجود الملف وإنشاؤه لو مش موجود
            file_exists = os.path.exists(file_path)
            if not file_exists:
                with open(file_path, 'w', newline='', encoding='utf-8') as file:
                    writer = csv.writer(file)
                    writer.writerow(headers)

            # قراءة البيانات والتأكد من عدم تكرار الإيميل
            user_exists = False
            with open(file_path, 'r', newline='', encoding='utf-8') as file:
                reader = csv.reader(file)
                next(reader)  # تجاهل الهيدر
                for row in reader:
                    if row[3].strip().lower() == self.var_email.get().strip().lower():
                        user_exists = True
                        break

            if user_exists:
                messagebox.showerror("Error", "User already exists, please try another email", parent=self.root)
                return

            # كتابة البيانات الجديدة
            with open(file_path, 'a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    self.var_fname.get(),
                    self.var_lname.get(),
                    self.var_cnum.get(),
                    self.var_email.get(),
                    self.var_ssq.get(),
                    self.var_sa.get(),
                    self.var_pwd.get()
                ])

            messagebox.showinfo("Success", "Successfully Registered!", parent=self.root)

        except PermissionError:
            messagebox.showerror("Error", "Permission denied! Please close the CSV file if it's open and try again.", parent=self.root)
        except Exception as es:
            messagebox.showerror("Error", f"Unexpected error occurred: {str(es)}", parent=self.root)



    def return_login(self):
        self.root.destroy()

# =====================main program Face deteion system====================

class Face_Recognition_System:
    def __init__(self,root,username):
        self.root=root
        self.username = username
        self.root.geometry("1500x768+0+0")
        self.root.title("Face_Recogonition_System")
        # تأكد من وجود المجلدات
        os.makedirs("data_img", exist_ok=True)
        os.makedirs("Images_GUI", exist_ok=True)
        # This part is image labels setting start 
        # first header image 
          
        # الحصول على أبعاد الشاشة تلقائيًا
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # تحميل وتعديل حجم صورة البانر لتناسب عرض الشاشة
        img = Image.open(os.path.join(os.path.dirname(__file__), "Images_GUI/banner.jpg"))
        banner_height = int(screen_height * 0.15)  # 15% من الشاشة
        img = img.resize((screen_width, banner_height), Image.Resampling.LANCZOS)
        self.photoimg = ImageTk.PhotoImage(img)
       
        # تعيين صورة البانر
        f_lb1 = Label(self.root, image=self.photoimg)
        f_lb1.place(x=0, y=0, width=screen_width, height=banner_height)

        # تحميل وتعديل صورة الخلفية لتناسب كل الشاشة
        bg1 = Image.open(os.path.join(os.path.dirname(__file__), "Images_GUI/bg3.jpg"))
        bg1 = bg1.resize((screen_width, screen_height), Image.Resampling.LANCZOS)
        self.photobg1 = ImageTk.PhotoImage(bg1)

        # تعيين صورة الخلفية
        bg_img = Label(self.root, image=self.photobg1)
        bg_img.place(x=0, y=banner_height, width=screen_width, height=screen_height - banner_height)



        #title section
        title_lb1 = Label(bg_img,text="Attendance Managment System Using Facial Recognition",font=("verdana",30,"bold"),bg="white",fg="navyblue")
        title_lb1.place(relx=0, rely=0, relwidth=1, relheight=0.06)


        # Create buttons below the section 
        # ------------------------------------------------------------------------------------------------------------------- 
        
        # student button 1
        std_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/std1.jpg"))
        std_img_btn=std_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.std_img1=ImageTk.PhotoImage(std_img_btn)

        std_b1 = Button(bg_img,command=self.student_pannels,image=self.std_img1,cursor="hand2")
        std_b1.place(x=350,y=100,width=180,height=180)

        std_b1_1 = Button(bg_img,command=self.student_pannels,text="Student Pannel",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        std_b1_1.place(x=350,y=280,width=180,height=45)

        # Detect Face  button 2
        det_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/det1.jpg"))
        det_img_btn=det_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.det_img1=ImageTk.PhotoImage(det_img_btn)

        det_b1 = Button(bg_img,command=self.face_rec,image=self.det_img1,cursor="hand2",)
        det_b1.place(x=580,y=100,width=180,height=180)

        det_b1_1 = Button(bg_img,command=self.face_rec,text="Face Detector",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        det_b1_1.place(x=580,y=280,width=180,height=45)

         # Attendance System  button 3
        att_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/att.jpg"))
        att_img_btn=att_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.att_img1=ImageTk.PhotoImage(att_img_btn)

        att_b1 = Button(bg_img,command=self.attendance_pannel,image=self.att_img1,cursor="hand2",)
        att_b1.place(x=810,y=100,width=180,height=180)

        att_b1_1 = Button(bg_img,command=self.attendance_pannel,text="Attendance",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        att_b1_1.place(x=810,y=280,width=180,height=45)

        

        # Top 4 buttons end.......
        # ---------------------------------------------------------------------------------------------------------------------------
        # Start below buttons.........
         # Train   button 5
        tra_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/tra1.jpg"))
        tra_img_btn=tra_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.tra_img1=ImageTk.PhotoImage(tra_img_btn)

        tra_b1 = Button(bg_img,command=self.train_pannels,image=self.tra_img1,cursor="hand2",)
        tra_b1.place(x=350,y=330,width=180,height=180)

        tra_b1_1 = Button(bg_img,command=self.train_pannels,text="Data Train",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        tra_b1_1.place(x=350,y=510,width=180,height=45)

        # Photo   button 6
        pho_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/dataset.jpg"))
        pho_img_btn=pho_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.pho_img1=ImageTk.PhotoImage(pho_img_btn)

        pho_b1 = Button(bg_img,command=self.open_img,image=self.pho_img1,cursor="hand2",)
        pho_b1.place(x=580,y=330,width=180,height=180)

        pho_b1_1 = Button(bg_img,command=self.open_img,text="Dataset",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        pho_b1_1.place(x=580,y=510,width=180,height=45)


        # exit   button 7
        exi_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/exi.jpg"))
        exi_img_btn=exi_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.exi_img1=ImageTk.PhotoImage(exi_img_btn)

        exi_b1 = Button(bg_img,command=self.Close,image=self.exi_img1,cursor="hand2",)
        exi_b1.place(x=810,y=330,width=180,height=180)

        exi_b1_1 = Button(bg_img,command=self.Close,text="Exit",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        exi_b1_1.place(x=810,y=510,width=180,height=45)

        top_frame = Frame(self.root, bg="lightgray")
        top_frame.pack(side=TOP, anchor="w", padx=10, pady=10)

        # عرض اسم المستخدم في أعلى اليسار
        username_label = Label(top_frame, text=f"Welcome: {self.username}", font=("verdana", 30, "bold"), bg="lightgray", fg="black")
        username_label.pack()


        
        
# ==================Funtion for Open Images Folder==================
    def open_img(self):
        os.startfile("data_img")
# ==================Functions Buttons=====================
    def student_pannels(self):
        self.new_window=Toplevel(self.root)
        self.app=Student(self.new_window)

    def train_pannels(self):
        self.new_window=Toplevel(self.root)
        self.app=Train(self.new_window)
    
    def face_rec(self):
        self.new_window=Toplevel(self.root)
        self.app=Face_Recognition(self.new_window)
    
    def attendance_pannel(self):
        self.new_window=Toplevel(self.root)
        self.app=Attendance(self.new_window)


    def Close(self):
     if self.root.winfo_exists():
        self.root.destroy()




if __name__ == "__main__":
    root=Tk()
    app=Login(root)
    root.mainloop()