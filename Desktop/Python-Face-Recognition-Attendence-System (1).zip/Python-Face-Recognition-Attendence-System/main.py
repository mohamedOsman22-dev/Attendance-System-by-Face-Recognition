from tkinter import*
from tkinter import ttk
from train import Train
from PIL import Image,ImageTk
from student import Student
from train import Train
from face_recognition import Face_Recognition
from attendance import Attendance
import os
from helpsupport import Helpsupport
import cv2

# مهم جدًا لحل مشكلة الـ DLL في OpenCV
os.add_dll_directory(os.path.dirname(cv2.__file__))

class Face_Recognition_System:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1500x799+0+0")
        self.root.title("Face_Recognition_System")

# This part is image labels setting start 
        # first header image  
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # تحميل وتعديل حجم صورة البانر لتناسب عرض الشاشة
        img = Image.open(os.path.join(os.path.dirname(__file__), "Images_GUI/banner.jpg"))
        banner_height = int(screen_height * 0.15)  # 15% من الشاشة
        img = img.resize((screen_width, banner_height), Image.Resampling.LANCZOS)
        self.photoimg = ImageTk.PhotoImage(img)

        # تعيين صورة البانر
        f_lb1 = Label(self.root, image=self.photoimg)
        f_lb1.place(x=0, y=0, width=screen_width, height=banner_height)

        # تحميل وتعديل صورة الخلفية لتناسب كل الشاشة
        bg1 = Image.open(os.path.join(os.path.dirname(__file__), "Images_GUI/bg3.jpg"))
        bg1 = bg1.resize((screen_width, screen_height), Image.Resampling.LANCZOS)
        self.photobg1 = ImageTk.PhotoImage(bg1)

        # تعيين صورة الخلفية
        bg_img = Label(self.root, image=self.photobg1)
        bg_img.place(x=0, y=banner_height, width=screen_width, height=screen_height - banner_height)



        #title section
        title_lb1 = Label(bg_img,text="Attendance Managment System Using Facial Recognition",font=("verdana",30,"bold"),bg="white",fg="navyblue")
        title_lb1.place(relx=0, rely=0, relwidth=1, relheight=0.06)


        # Create buttons below the section 
        # ------------------------------------------------------------------------------------------------------------------- 
        # student button 1
        std_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/std1.jpg"))
        std_img_btn=std_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.std_img1=ImageTk.PhotoImage(std_img_btn)

        std_b1 = Button(bg_img,command=self.student_pannels,image=self.std_img1,cursor="hand2")
        std_b1.place(x=350,y=100,width=180,height=180)

        std_b1_1 = Button(bg_img,command=self.student_pannels,text="Student Pannel",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        std_b1_1.place(x=350,y=280,width=180,height=45)

        # Detect Face  button 2
        det_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/det1.jpg"))
        det_img_btn=det_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.det_img1=ImageTk.PhotoImage(det_img_btn)

        det_b1 = Button(bg_img,command=self.face_rec,image=self.det_img1,cursor="hand2",)
        det_b1.place(x=580,y=100,width=180,height=180)

        det_b1_1 = Button(bg_img,command=self.face_rec,text="Face Detector",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        det_b1_1.place(x=580,y=280,width=180,height=45)

         # Attendance System  button 3
        att_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/att.jpg"))
        att_img_btn=att_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.att_img1=ImageTk.PhotoImage(att_img_btn)

        att_b1 = Button(bg_img,command=self.attendance_pannel,image=self.att_img1,cursor="hand2",)
        att_b1.place(x=810,y=100,width=180,height=180)

        att_b1_1 = Button(bg_img,command=self.attendance_pannel,text="Attendance",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        att_b1_1.place(x=810,y=280,width=180,height=45)

        

        # Top 4 buttons end.......
        # ---------------------------------------------------------------------------------------------------------------------------
        # Start below buttons.........
         # Train   button 5
        tra_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/tra1.jpg"))
        tra_img_btn=tra_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.tra_img1=ImageTk.PhotoImage(tra_img_btn)

        tra_b1 = Button(bg_img,command=self.train_pannels,image=self.tra_img1,cursor="hand2",)
        tra_b1.place(x=350,y=330,width=180,height=180)

        tra_b1_1 = Button(bg_img,command=self.train_pannels,text="Data Train",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        tra_b1_1.place(x=350,y=510,width=180,height=45)

        # Photo   button 6
        pho_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/dataset.jpg"))
        pho_img_btn=pho_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.pho_img1=ImageTk.PhotoImage(pho_img_btn)

        pho_b1 = Button(bg_img,command=self.open_img,image=self.pho_img1,cursor="hand2",)
        pho_b1.place(x=580,y=330,width=180,height=180)

        pho_b1_1 = Button(bg_img,command=self.open_img,text="Dataset",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        pho_b1_1.place(x=580,y=510,width=180,height=45)


        # exit   button 7
        exi_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/exi.jpg"))
        exi_img_btn=exi_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.exi_img1=ImageTk.PhotoImage(exi_img_btn)

        exi_b1 = Button(bg_img,command=self.Close,image=self.exi_img1,cursor="hand2",)
        exi_b1.place(x=810,y=330,width=180,height=180)

        exi_b1_1 = Button(bg_img,command=self.Close,text="Exit",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        exi_b1_1.place(x=810,y=510,width=180,height=45)

# ==================Funtion for Open Images Folder==================
    def open_img(self):
        os.startfile("data_img")
# ==================Functions Buttons=====================
    def student_pannels(self):
        self.new_window=Toplevel(self.root)
        self.app=Student(self.new_window)

    def train_pannels(self):
        self.new_window=Toplevel(self.root)
        self.app=Train(self.new_window)
    
    def face_rec(self):
        self.new_window=Toplevel(self.root)
        self.app=Face_Recognition(self.new_window)
    
    def attendance_pannel(self):
        self.new_window=Toplevel(self.root)
        self.app=Attendance(self.new_window)
    

    def Close(self):
     if self.root.winfo_exists():
        self.root.destroy()

    
    


if __name__ == "__main__":
    root=Tk()
    obj=Face_Recognition_System(root)
    root.mainloop()
