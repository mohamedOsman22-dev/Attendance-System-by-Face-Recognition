import re
from tkinter import* 
from tkinter import ttk,PhotoImage
from PIL import Image,ImageTk
from tkinter import messagebox
import os
import csv
import cv2

# مهم جدًا لحل مشكلة الـ DLL في OpenCV
os.add_dll_directory(os.path.dirname(cv2.__file__))



class Register:
    def __init__(self,root):
        self.root=root
        self.root.title("Register")
        self.root.geometry("1366x768+0+0")
        self.show_password = False
        # ============ Variables =================
        self.var_fname=StringVar()
        self.var_lname=StringVar()
        self.var_cnum=StringVar()
        self.var_email=StringVar()
        self.var_ssq=StringVar()
        self.var_sa=StringVar()
        self.var_pwd=StringVar()
        self.var_cpwd=StringVar()
        self.var_check=IntVar()

        self.bg = ImageTk.PhotoImage(file=os.path.join(os.path.dirname(__file__), "Images_GUI/bgReg.jpg"))

        lb1_bg=Label(self.root,image=self.bg)
        lb1_bg.place(x=0,y=0, relwidth=1,relheight=1)

        frame= Frame(self.root,bg="#F2F2F2")
        frame.place(x=100,y=80,width=900,height=580)
    

        get_str = Label(frame,text="Registration",font=("times new roman",30,"bold"),fg="#002B53",bg="#F2F2F2")
        get_str.place(x=350,y=130)

        #label1 
        fname =lb1= Label(frame,text="First Name:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        fname.place(x=100,y=200)

        #entry1 
        self.txtuser=ttk.Entry(frame,textvariable=self.var_fname,font=("times new roman",15,"bold"))
        self.txtuser.place(x=103,y=225,width=270)


        #label2 
        lname =lb1= Label(frame,text="Last Name:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        lname.place(x=100,y=270)

        #entry2 
        self.txtpwd=ttk.Entry(frame,textvariable=self.var_lname,font=("times new roman",15,"bold"))
        self.txtpwd.place(x=103,y=295,width=270)

        # ==================== section 2 -------- 2nd Columan===================

        #label1 
        cnum =lb1= Label(frame,text="Contact No:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        cnum.place(x=530,y=200)

        #entry1 
        self.txtuser=ttk.Entry(frame,textvariable=self.var_cnum,font=("times new roman",15,"bold"))
        self.txtuser.place(x=533,y=225,width=270)


        #label2 
        email =lb1= Label(frame,text="Email:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        email.place(x=530,y=270)

        #entry2 
        self.txtpwd=ttk.Entry(frame,textvariable=self.var_email,font=("times new roman",15,"bold"))
        self.txtpwd.place(x=533,y=295,width=270)

        # ========================= Section 3 --- 1 Columan=================

        #label1 
        ssq =lb1= Label(frame,text="Select Security Question:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        ssq.place(x=100,y=350)

        #Combo Box1
        self.combo_security = ttk.Combobox(frame,textvariable=self.var_ssq,font=("times new roman",15,"bold"),state="readonly")
        self.combo_security["values"]=("Select","Your Date of Birth","Your Nick Name","Your Favorite Book")
        self.combo_security.current(0)
        self.combo_security.place(x=103,y=375,width=270)


        #label2 
        sa =lb1= Label(frame,text="Security Answer:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        sa.place(x=100,y=420)

        #entry2 
        self.txtpwd=ttk.Entry(frame,textvariable=self.var_sa,font=("times new roman",15,"bold"))
        self.txtpwd.place(x=103,y=445,width=270)

        # ========================= Section 4-----Column 2=============================

        #label1 
        pwd =lb1= Label(frame,text="Password:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        pwd.place(x=530,y=350)

        #entry1 
        self.txtpwd=ttk.Entry(frame,textvariable=self.var_pwd,show="*",font=("times new roman",15,"bold"))
        self.txtpwd.place(x=533,y=375,width=270)


        #label2 
        cpwd =lb1= Label(frame,text="Confirm Password:",font=("times new roman",15,"bold"),fg="#002B53",bg="#F2F2F2")
        cpwd.place(x=530,y=420)

        #entry2 
        self.txtcpwd=ttk.Entry(frame,textvariable=self.var_cpwd,show="*",font=("times new roman",15,"bold"))
        self.txtcpwd.place(x=533,y=445,width=270)

        # Checkbutton
        checkbtn = Checkbutton(frame,variable=self.var_check,text="I Agree the Terms & Conditions",font=("times new roman",13,"bold"),fg="#002B53",bg="#F2F2F2")
        checkbtn.place(x=100,y=480,width=270)


        # Creating Button Register
        loginbtn=Button(frame,command=self.reg,text="Register",font=("times new roman",15,"bold"),bd=0,relief=RIDGE,fg="#fff",bg="#002B53",activeforeground="white",activebackground="#007ACC")
        loginbtn.place(x=320,y=510,width=270,height=35)

        # Creating Button Login
        loginbtn = Button(frame,command=self.return_login, text="Login", font=("times new roman", 15, "bold"), bd=0, relief=RIDGE, fg="#fff", bg="#002B53", activeforeground="white", activebackground="#007ACC")
        loginbtn.place(x=810, y=510, width=70, height=35)


        self.btn_toggle_password = Button(frame, text="👁️", command=self.toggle_passwords, font=("times new roman", 12), bg="#F2F2F2", bd=0)
        self.btn_toggle_password.place(x=810, y=375, width=40, height=100)


    def toggle_passwords(self):
        if self.show_password:
            self.txtpwd.config(show="*")
            self.txtcpwd.config(show="*")
            self.btn_toggle_password.config(text="👁️")
            self.show_password = False
        else:
            self.txtpwd.config(show="")
            self.txtcpwd.config(show="")
            self.btn_toggle_password.config(text="🙈")
            self.show_password = True



    def reg(self):
    # تحقق من ملء الحقول
        if self.var_fname.get() == "" or self.var_email.get() == "" or self.var_ssq.get() == "Select" or self.var_pwd.get() == "":
            messagebox.showerror("Error", "All Fields Required!", parent=self.root)
            return

        # تحقق من صيغة الإيميل (ينتهي بـ .com فقط)
        email_pattern = r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.com$'
        if not re.match(email_pattern, self.var_email.get()):
            messagebox.showerror("Error", "Invalid email format! Use e.g. user@example.com", parent=self.root)
            return

        # تحقق من صيغة الرقم (أرقام فقط)
        phone_pattern = r'^\d+$'
        if not re.match(phone_pattern, self.var_cnum.get()):
            messagebox.showerror("Error", "Invalid phone number! Please enter numbers only", parent=self.root)
            return

        # تحقق من تطابق الباسورد
        if self.var_pwd.get() != self.var_cpwd.get():
            messagebox.showerror("Error", "Passwords do not match!", parent=self.root)
            return

        # تحقق من الموافقة على الشروط
        if self.var_check.get() == 0:
            messagebox.showerror("Error", "Please agree to the terms and conditions", parent=self.root)
            return

        try:
            file_path = 'users.csv'
            headers = ["First Name", "Last Name", "Contact Number", "Email", "Security Question", "Security Answer", "Password"]

            # تأكد من وجود الملف وإنشاؤه لو مش موجود
            file_exists = os.path.exists(file_path)
            if not file_exists:
                with open(file_path, 'w', newline='', encoding='utf-8') as file:
                    writer = csv.writer(file)
                    writer.writerow(headers)

            # قراءة البيانات والتأكد من عدم تكرار الإيميل
            user_exists = False
            with open(file_path, 'r', newline='', encoding='utf-8') as file:
                reader = csv.reader(file)
                next(reader)  # تجاهل الهيدر
                for row in reader:
                    if row[3].strip().lower() == self.var_email.get().strip().lower():
                        user_exists = True
                        break

            if user_exists:
                messagebox.showerror("Error", "User already exists, please try another email", parent=self.root)
                return

            # كتابة البيانات الجديدة
            with open(file_path, 'a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    self.var_fname.get(),
                    self.var_lname.get(),
                    self.var_cnum.get(),
                    self.var_email.get(),
                    self.var_ssq.get(),
                    self.var_sa.get(),
                    self.var_pwd.get()
                ])

            messagebox.showinfo("Success", "Successfully Registered!", parent=self.root)

        except PermissionError:
            messagebox.showerror("Error", "Permission denied! Please close the CSV file if it's open and try again.", parent=self.root)
        except Exception as es:
            messagebox.showerror("Error", f"Unexpected error occurred: {str(es)}", parent=self.root)


    def return_login(self):
        self.root.destroy()
        import subprocess
        subprocess.Popen(["python", "login.py"])


if __name__ == "__main__":
    root=Tk()
    app=Register(root)
    root.mainloop()