import re
from tkinter import* 
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import csv
import cv2
import os
from datetime import datetime
import mediapipe as mp


os.add_dll_directory(os.path.dirname(cv2.__file__))

class Student:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1366x768+0+0")
        self.root.title("Student Pannel")
        
        os.makedirs("data_img", exist_ok=True)
        #-----------Variables-------------------
        self.var_dep=StringVar()
        self.var_new_course = StringVar()
        self.var_course=StringVar()
        self.var_year=StringVar()
        self.var_semester=StringVar()
        self.var_std_id=StringVar()
        self.var_std_name=StringVar()
        self.var_div=StringVar()
        self.var_roll=StringVar()
        self.var_gender=StringVar()
        self.var_dob=StringVar()
        self.var_email=StringVar()
        self.var_mob=StringVar()
        self.var_address=StringVar()
        self.var_teacher=StringVar()

    # This part is image labels setting start 
        # first header image  
      
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        
        img = Image.open(os.path.join(os.path.dirname(__file__), "Images_GUI/banner.jpg"))
        img = img.resize((screen_width, 130), Image.Resampling.LANCZOS)
        self.photoimg = ImageTk.PhotoImage(img)

        f_lb1 = Label(self.root, image=self.photoimg)
        f_lb1.pack(fill="x")  

       
        bg1 = Image.open(os.path.join(os.path.dirname(__file__), "Images_GUI/bg3.jpg"))
        bg1 = bg1.resize((screen_width, screen_height - 130), Image.Resampling.LANCZOS)
        self.photobg1 = ImageTk.PhotoImage(bg1)

        bg_img = Label(self.root, image=self.photobg1)
        bg_img.pack(fill="both", expand=True)



        #title section
        title_lb1 = Label(bg_img,text="Welcome to Student Pannel",font=("verdana",30,"bold"),bg="white",fg="navyblue")
        title_lb1.place(relx=0, rely=0, relwidth=1, relheight=0.06)


        # Creating Frame 
        main_frame = Frame(bg_img,bd=2,bg="white") #bd mean border 
        main_frame.place(x=5,y=55,width=1355,height=510)

        # Left Label Frame 
        left_frame = LabelFrame(main_frame,bd=2,bg="white",relief=RIDGE,text="Student Details",font=("verdana",12,"bold"),fg="navyblue")
        left_frame.place(x=10,y=10,width=660,height=480)

        # Current Course 
        current_course_frame = LabelFrame(left_frame,bd=2,bg="white",relief=RIDGE,text="Current Course",font=("verdana",12,"bold"),fg="navyblue")
        current_course_frame.place(x=10,y=5,width=635,height=150)

        #label Department
        dep_label=Label(current_course_frame,text="Department",font=("verdana",12,"bold"),bg="white",fg="navyblue")
        dep_label.grid(row=0,column=0,padx=5,pady=15)

        #combo box 
        dep_combo=ttk.Combobox(current_course_frame,textvariable=self.var_dep,width=15,font=("verdana",12,"bold"),state="readonly")
        dep_combo["values"]=("Select Department","BSCS","BSIT")
        dep_combo.current(0)
        dep_combo.grid(row=0,column=1,padx=5,pady=15,sticky=W)

        # -----------------------------------------------------

        #label Course
        cou_label=Label(current_course_frame,text="Course",font=("verdana",12,"bold"),bg="white",fg="navyblue")
        cou_label.grid(row=0,column=2,padx=5,pady=15)

        #combo box 
        cou_combo=ttk.Combobox(current_course_frame,textvariable=self.var_course,width=15,font=("verdana",12,"bold"),state="readonly")
        cou_combo["values"]=("Select Course","Introduction to Programming","Object Oriented Programming"," Data Structures",
                             "Database Management Systems"," Artificial Intelligence","Machine Learning")
        cou_combo.current(0)
        cou_combo.grid(row=0,column=3,padx=5,pady=15,sticky=W)

        #-------------------------------------------------------------

        #label Year
        year_label=Label(current_course_frame,text="Year",font=("verdana",12,"bold"),bg="white",fg="navyblue")
        year_label.grid(row=1,column=0,padx=5,sticky=W)

        #combo box 
        year_combo=ttk.Combobox(current_course_frame,textvariable=self.var_year,width=14,font=("verdana",12,"bold"),state="readonly")
        year_combo["values"]=("Select Year","2017-21","2018-22","2019-23","2020-24","2021-25")
        year_combo.current(0)
        year_combo.grid(row=1,column=1,padx=5,pady=15,sticky=W)

        #-----------------------------------------------------------------

        #label Semester 
        year_label=Label(current_course_frame,text="Semester",font=("verdana",12,"bold"),bg="white",fg="navyblue")
        year_label.grid(row=1,column=2,padx=5,sticky=W)

        #combo box 
        year_combo=ttk.Combobox(current_course_frame,textvariable=self.var_semester,width=14,font=("verdana",12,"bold"),state="readonly")
        year_combo["values"]=("Select Semester","Semester-1","Semester-2","Semester-3","Semester-4","Semester-5","Semester-6","Semester-7","Semester-8")
        year_combo.current(0)
        year_combo.grid(row=1,column=3,padx=5,pady=15,sticky=W)

        #Class Student Information
        class_Student_frame = LabelFrame(left_frame,bd=2,bg="white",relief=RIDGE,text="Class Student Information",font=("verdana",12,"bold"),fg="navyblue")
        class_Student_frame.place(x=10,y=160,width=635,height=230)

        #Student id
        studentId_label = Label(class_Student_frame,text="Std-ID:",font=("verdana",12,"bold"),fg="navyblue",bg="white")
        studentId_label.grid(row=0,column=0,padx=5,pady=5,sticky=W)

        studentId_entry = ttk.Entry(class_Student_frame,textvariable=self.var_std_id,width=14,font=("verdana",12,"bold"))
        studentId_entry.grid(row=0,column=1,padx=5,pady=5,sticky=W)

        #Student name
        student_name_label = Label(class_Student_frame,text="Std-Name:",font=("verdana",12,"bold"),fg="navyblue",bg="white")
        student_name_label.grid(row=0,column=2,padx=5,pady=5,sticky=W)

        student_name_entry = ttk.Entry(class_Student_frame,textvariable=self.var_std_name,width=14,font=("verdana",12,"bold"))
        student_name_entry.grid(row=0,column=3,padx=5,pady=5,sticky=W)

        #Class Didvision
        student_div_label = Label(class_Student_frame,text="Class Division:",font=("verdana",12,"bold"),fg="navyblue",bg="white")
        student_div_label.grid(row=1,column=0,padx=5,pady=5,sticky=W)

        div_combo=ttk.Combobox(class_Student_frame,textvariable=self.var_div,width=14,font=("verdana",12,"bold"),state="readonly")
        div_combo["values"]=("Morning","Evening")
        div_combo.current(0)
        div_combo.grid(row=1,column=1,padx=5,pady=5,sticky=W)

        #Roll No
        student_roll_label = Label(class_Student_frame,text="Roll-No:",font=("verdana",12,"bold"),fg="navyblue",bg="white")
        student_roll_label.grid(row=1,column=2,padx=5,pady=5,sticky=W)

        student_roll_entry = ttk.Entry(class_Student_frame,textvariable=self.var_roll,width=14,font=("verdana",12,"bold"))
        student_roll_entry.grid(row=1,column=3,padx=5,pady=5,sticky=W)

        #Gender
        student_gender_label = Label(class_Student_frame,text="Gender:",font=("verdana",12,"bold"),fg="navyblue",bg="white")
        student_gender_label.grid(row=2,column=0,padx=5,pady=5,sticky=W)

        #combo box 
        gender_combo=ttk.Combobox(class_Student_frame,textvariable=self.var_gender,width=14,font=("verdana",12,"bold"),state="readonly")
        gender_combo["values"]=("Male","Female","Others")
        gender_combo.current(0)
        gender_combo.grid(row=2,column=1,padx=5,pady=5,sticky=W)

        #Date of Birth
        student_dob_label = Label(class_Student_frame,text="DOB:",font=("verdana",12,"bold"),fg="navyblue",bg="white")
        student_dob_label.grid(row=2,column=2,padx=5,pady=5,sticky=W)

        student_dob_entry = ttk.Entry(class_Student_frame,textvariable=self.var_dob,width=14,font=("verdana",12,"bold"))
        student_dob_entry.grid(row=2,column=3,padx=5,pady=5,sticky=W)

        #Email
        student_email_label = Label(class_Student_frame,text="Email:",font=("verdana",12,"bold"),fg="navyblue",bg="white")
        student_email_label.grid(row=3,column=0,padx=5,pady=5,sticky=W)

        student_email_entry = ttk.Entry(class_Student_frame,textvariable=self.var_email,width=14,font=("verdana",12,"bold"))
        student_email_entry.grid(row=3,column=1,padx=5,pady=5,sticky=W)

        #Phone Number
        student_mob_label = Label(class_Student_frame,text="Mob-No:",font=("verdana",12,"bold"),fg="navyblue",bg="white")
        student_mob_label.grid(row=3,column=2,padx=5,pady=5,sticky=W)

        student_mob_entry = ttk.Entry(class_Student_frame,textvariable=self.var_mob,width=14,font=("verdana",12,"bold"))
        student_mob_entry.grid(row=3,column=3,padx=5,pady=5,sticky=W)

        #Address
        student_address_label = Label(class_Student_frame,text="Address:",font=("verdana",12,"bold"),fg="navyblue",bg="white")
        student_address_label.grid(row=4,column=0,padx=5,pady=5,sticky=W)

        student_address_entry = ttk.Entry(class_Student_frame,textvariable=self.var_address,width=14,font=("verdana",12,"bold"))
        student_address_entry.grid(row=4,column=1,padx=5,pady=5,sticky=W)

        #Teacher Name
        student_tutor_label = Label(class_Student_frame,text="Tutor Name:",font=("verdana",12,"bold"),fg="navyblue",bg="white")
        student_tutor_label.grid(row=4,column=2,padx=5,pady=5,sticky=W)

        student_tutor_entry = ttk.Entry(class_Student_frame,textvariable=self.var_teacher,width=14,font=("verdana",12,"bold"))
        student_tutor_entry.grid(row=4,column=3,padx=5,pady=5,sticky=W)

        #Radio Buttons
        self.var_radio1=StringVar()
        radiobtn1=ttk.Radiobutton(class_Student_frame,text="Take Photo Sample",variable=self.var_radio1,value="Yes")
        radiobtn1.grid(row=5,column=0,padx=5,pady=5,sticky=W)

        radiobtn1=ttk.Radiobutton(class_Student_frame,text="No Photo Sample",variable=self.var_radio1,value="No")
        radiobtn1.grid(row=5,column=1,padx=5,pady=5,sticky=W)
        
        self.var_new_course = StringVar()
        new_course_label = Label(class_Student_frame, text="New Course:", font=("verdana", 12, "bold"), bg="white", fg="navyblue")
        new_course_label.grid(row=5, column=2, padx=5, pady=5, sticky=W)

        # ComboBox: New Course
        self.var_new_course = StringVar()
        new_course_combo = ttk.Combobox(class_Student_frame, textvariable=self.var_new_course, font=("verdana", 12), width=13, state="readonly")
        new_course_combo["values"] = (
            "Select Course", "Introduction to Programming", "Object-Oriented Programming",
            "Data Structures", "Database Management Systems",
            "Artificial Intelligence", "Machine Learning"
        )
        new_course_combo.current(0)
        new_course_combo.grid(row=5, column=3, padx=5, pady=5, sticky=W)


        #Button Frame
        btn_frame = Frame(left_frame,bd=2,bg="white",relief=RIDGE)
        btn_frame.place(x=10,y=390,width=635,height=60)

        # Save button
        save_btn = Button(btn_frame, command=self.add_data, text="Save", width=7, font=("verdana", 12, "bold"), fg="white", bg="navyblue")
        save_btn.grid(row=0, column=0, padx=5, pady=10, sticky=W)

        # Update button
        update_btn = Button(btn_frame, command=self.update_data, text="Update", width=7, font=("verdana", 12, "bold"), fg="white", bg="navyblue")
        update_btn.grid(row=0, column=1, padx=5, pady=10, sticky=W)

        # Delete button
        del_btn = Button(btn_frame, command=self.delete_data, text="Delete", width=7, font=("verdana", 12, "bold"), fg="white", bg="navyblue")
        del_btn.grid(row=0, column=2, padx=5, pady=10, sticky=W)

        # Take photo button
        take_photo_btn = Button(btn_frame, command=self.generate_dataset, text="Take Pic", width=6, font=("verdana", 12, "bold"), fg="white", bg="navyblue")
        take_photo_btn.grid(row=0, column=3, padx=5, pady=10, sticky=W)

        # Reset button
        reset_btn = Button(btn_frame, command=self.reset_data, text="Reset", width=7, font=("verdana", 12, "bold"), fg="white", bg="navyblue")
        reset_btn.grid(row=0, column=4, padx=5, pady=10, sticky=W)

       
        # Update All Courses button (تحت الكومبو في نفس العمود)
        update_all_btn = Button(btn_frame, command=self.update_all_courses, text="Update All", width=12, font=("verdana", 12, "bold"), fg="white", bg="navyblue")
        update_all_btn.grid(row=0, column=5, padx=5, pady= 10, sticky=W)





        #----------------------------------------------------------------------
        # Right Label Frame 
        right_frame = LabelFrame(main_frame,bd=2,bg="white",relief=RIDGE,text="Student Details",font=("verdana",12,"bold"),fg="navyblue")
        right_frame.place(x=680,y=10,width=660,height=480)

        #Searching System in Right Label Frame 
        search_frame = LabelFrame(right_frame,bd=2,bg="white",relief=RIDGE,text="Search System",font=("verdana",12,"bold"),fg="navyblue")
        search_frame.place(x=10,y=5,width=635,height=80)

        #Phone Number
        search_label = Label(search_frame,text="Search:",font=("verdana",12,"bold"),fg="navyblue",bg="white")
        search_label.grid(row=0,column=0,padx=5,pady=5,sticky=W)
        self.var_searchTX=StringVar()
        #combo box 
        search_combo=ttk.Combobox(search_frame,textvariable=self.var_searchTX,width=12,font=("verdana",12,"bold"),state="readonly")
        search_combo["values"]=("Select", "Student_ID", "Name", "Roll Number")
        search_combo.current(0)
        search_combo.grid(row=0,column=1,padx=5,pady=15,sticky=W)

        self.var_search=StringVar()
        search_entry = ttk.Entry(search_frame,textvariable=self.var_search,width=12,font=("verdana",12,"bold"))
        search_entry.grid(row=0,column=2,padx=5,pady=5,sticky=W)

        search_btn=Button(search_frame,command=self.search_data,text="Search",width=9,font=("verdana",12,"bold"),fg="white",bg="navyblue")
        search_btn.grid(row=0,column=3,padx=5,pady=10,sticky=W)

        showAll_btn=Button(search_frame,command=self.fetch_data,text="Show All",width=8,font=("verdana",12,"bold"),fg="white",bg="navyblue")
        showAll_btn.grid(row=0,column=4,padx=5,pady=10,sticky=W)

        # -----------------------------Table Frame-------------------------------------------------
        #Table Frame 
        #Searching System in Right Label Frame 
        table_frame = Frame(right_frame,bd=2,bg="white",relief=RIDGE)
        table_frame.place(x=10,y=90,width=635,height=360)

        #scroll bar 
        scroll_x = ttk.Scrollbar(table_frame,orient=HORIZONTAL)
        scroll_y = ttk.Scrollbar(table_frame,orient=VERTICAL)

        #create table 
        self.student_table = ttk.Treeview(table_frame,column=("ID","Name","Dep","Course","Year","Sem","Div","Gender","DOB","Mob-No","Address","Roll-No","Email","Teacher","Photo"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)

        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_x.config(command=self.student_table.xview)
        scroll_y.config(command=self.student_table.yview)

        self.student_table.heading("ID",text="StudentID")
        self.student_table.heading("Name",text="Name")
        self.student_table.heading("Dep",text="Department")
        self.student_table.heading("Course",text="Course")
        self.student_table.heading("Year",text="Year")
        self.student_table.heading("Sem",text="Semester")
        self.student_table.heading("Div",text="Division")
        self.student_table.heading("Gender",text="Gender")
        self.student_table.heading("DOB",text="DOB")
        self.student_table.heading("Mob-No",text="Mob-No")
        self.student_table.heading("Address",text="Address")
        self.student_table.heading("Roll-No",text="Roll-No")
        self.student_table.heading("Email",text="Email")
        self.student_table.heading("Teacher",text="Teacher")
        self.student_table.heading("Photo",text="PhotoSample")
        self.student_table["show"]="headings"


        # Set Width of Colums 
        self.student_table.column("ID",width=100)
        self.student_table.column("Name",width=120)
        self.student_table.column("Dep",width=100)
        self.student_table.column("Course",width=180)
        self.student_table.column("Year",width=100)
        self.student_table.column("Sem",width=100)
        self.student_table.column("Div",width=100)
        self.student_table.column("Gender",width=100)
        self.student_table.column("DOB",width=100)
        self.student_table.column("Mob-No",width=100)
        self.student_table.column("Address",width=100)
        self.student_table.column("Roll-No",width=100)
        self.student_table.column("Email",width=100)
        self.student_table.column("Teacher",width=100)
        self.student_table.column("Photo",width=100)


        self.student_table.pack(fill=BOTH,expand=1)
        self.student_table.bind("<ButtonRelease>",self.get_cursor)
        self.fetch_data()
# ==================Function Decleration==============================

    
    def update_all_courses(self):
        new_course = self.var_new_course.get()
        if new_course == "Select Course":
            messagebox.showerror("Error", "Please select a new course to update!", parent=self.root)
            return

        file_path = "students.csv"
        if not os.path.exists(file_path):
            messagebox.showerror("Error", "Student file not found!", parent=self.root)
            return

        try:
            with open(file_path, mode='r', newline='', encoding='utf-8') as file:
                reader = csv.reader(file)
                header = next(reader)
                rows = list(reader)

            # Update Course column (index 3)
            for row in rows:
                row[3] = new_course

            with open(file_path, mode='w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(header)
                writer.writerows(rows)

            self.fetch_data()
            messagebox.showinfo("Success", f"Course updated to '{new_course}' for all students.", parent=self.root)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to update courses: {str(e)}", parent=self.root)


    def add_data(self):
        if (self.var_dep.get() == "Select Department" or
            self.var_course.get() == "Select Course" or
            self.var_year.get() == "Select Year" or
            self.var_semester.get() == "Select Semester" or
            self.var_std_id.get() == "" or
            self.var_std_name.get() == "" or
            self.var_div.get() == "" or
            self.var_roll.get() == "" or
            self.var_gender.get() == "" or
            self.var_dob.get() == "" or
            self.var_email.get() == "" or
            self.var_mob.get() == "" or
            self.var_address.get() == "" or
            self.var_teacher.get() == ""):
            messagebox.showerror("Error", "Please Fill All Fields are Required!", parent=self.root)
            return

        #  Validation rules
        if not self.var_std_id.get().isdigit():
            messagebox.showerror("Error", "Student ID must be digits only!", parent=self.root)
            return

        if not self.var_roll.get().isdigit():
            messagebox.showerror("Error", "Roll Number must be digits only!", parent=self.root)
            return

        if not self.var_mob.get().isdigit():
            messagebox.showerror("Error", "Mobile Number must be digits!", parent=self.root)
            return

        email_pattern = r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.com$'
        if not re.match(email_pattern, self.var_email.get()):
            messagebox.showerror("Error", "Invalid email format! Use e.g. user@example.com", parent=self.root)
            return

        try:
            datetime.strptime(self.var_dob.get(), "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Error", "DOB must be in format YYYY-MM-DD", parent=self.root)
            return

        try:
            file_path = "students.csv"
            new_data = [
                self.var_std_id.get(),
                self.var_std_name.get(),
                self.var_dep.get(),
                self.var_course.get(),
                self.var_year.get(),
                self.var_semester.get(),
                self.var_div.get(),
                self.var_gender.get(),
                self.var_dob.get(),
                self.var_mob.get(),
                self.var_address.get(),
                self.var_roll.get(),
                self.var_email.get(),
                self.var_teacher.get(),
                self.var_radio1.get()
            ]

            file_exists = os.path.exists(file_path)
            updated = False
            rows = []

            if file_exists:
                with open(file_path, mode='r', newline='') as file:
                    reader = csv.reader(file)
                    rows = list(reader)

                for i in range(1, len(rows)):
                    row = rows[i]
                    if row[0] == self.var_std_id.get():
                        rows[i] = new_data
                        updated = True
                        break
                    elif row[11] == self.var_roll.get():
                        messagebox.showerror("Error", "Roll Number already exists!", parent=self.root)
                        return
                    elif row[9] == self.var_mob.get():
                        messagebox.showerror("Error", "Mobile Number already exists!", parent=self.root)
                        return
                    elif row[12] == self.var_email.get():
                        messagebox.showerror("Error", "Email already exists!", parent=self.root)
                        return

            if not updated:
                for row in rows[1:]:
                    if row[0] == self.var_std_id.get():
                        messagebox.showerror("Error", "Student ID already exists!", parent=self.root)
                        return
                    elif row[11] == self.var_roll.get():
                        messagebox.showerror("Error", "Roll Number already exists!", parent=self.root)
                        return
                    elif row[9] == self.var_mob.get():
                        messagebox.showerror("Error", "Mobile Number already exists!", parent=self.root)
                        return
                    elif row[12] == self.var_email.get():
                        messagebox.showerror("Error", "Email already exists!", parent=self.root)
                        return

                rows.append(new_data)

            with open(file_path, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([
                    'Student_ID', 'Name', 'department', 'course', 'year',
                    'semester', 'division', 'gender', 'dob', 'mobile',
                    'address', 'Roll_No', 'email', 'teacher', 'photo_sample'
                ])
                writer.writerows(rows[1:] if file_exists else rows)

            self.fetch_data()
            messagebox.showinfo("Success", "All Records are Saved!", parent=self.root)

        except Exception as es:
            messagebox.showerror("Error", f"Due to: {str(es)}", parent=self.root)



    # ===========================Fetch data form database to table ================================


    def fetch_data(self):
        file_path = "students.csv"
        headers = [
            "Student_ID", "Name", "Department", "Course", "Year", "Semester",
            "Division", "Gender", "DOB", "Mobile_No", "Address",
            "Roll_No", "Email", "Teacher_Name", "PhotoSample"
        ]

       
        if not os.path.exists(file_path):
            with open(file_path, mode='w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(headers)
            messagebox.showinfo("Info", "No student data found. A new file has been created.", parent=self.root)
            return  # لا داعي لعرض الجدول الآن لأنه فاضي

        try:
            with open(file_path, mode='r', newline='', encoding='utf-8') as file:
                reader = csv.reader(file)
                data = list(reader)

                if len(data) > 1:
                    self.student_table.delete(*self.student_table.get_children())
                    for row in data[1:]:  
                        self.student_table.insert("", END, values=row)
                else:
                    self.student_table.delete(*self.student_table.get_children())  # الملف فاضي غير الهيدر

        except Exception as es:
            messagebox.showerror("Error", f"Due to: {str(es)}", parent=self.root)




    #================================get cursor function=======================

    def get_cursor(self,event=""):
        cursor_focus = self.student_table.focus()
        content = self.student_table.item(cursor_focus)
        data = content["values"]
        if data and len(data) >= 15:
            self.var_std_id.set(data[0]),
            self.var_std_name.set(data[1]),
            self.var_dep.set(data[2]),
            self.var_course.set(data[3]),
            self.var_year.set(data[4]),
            self.var_semester.set(data[5]),
            self.var_div.set(data[6]),
            self.var_gender.set(data[7]),
            self.var_dob.set(data[8]),
            self.var_mob.set(data[9]),
            self.var_address.set(data[10]),
            self.var_roll.set(data[11]),
            self.var_email.set(data[12]),
            self.var_teacher.set(data[13]),
            self.var_radio1.set(data[14])
    # ========================================Update Function==========================

 
    def update_data(self):
        if (self.var_dep.get() == "Select Department" or
            self.var_course.get() == "Select Course" or
            self.var_year.get() == "Select Year" or
            self.var_semester.get() == "Select Semester" or
            self.var_std_id.get() == "" or
            self.var_std_name.get() == "" or
            self.var_div.get() == "" or
            self.var_roll.get() == "" or
            self.var_gender.get() == "" or
            self.var_dob.get() == "" or
            self.var_email.get() == "" or
            self.var_mob.get() == "" or
            self.var_address.get() == "" or
            self.var_teacher.get() == ""):
            messagebox.showerror("Error", "Please Fill All Fields are Required!", parent=self.root)
            return

        # Validation rules
        if not self.var_std_id.get().isdigit():
            messagebox.showerror("Error", "Student ID must be digits only!", parent=self.root)
            return

        if not self.var_roll.get().isdigit():
            messagebox.showerror("Error", "Roll Number must be digits only!", parent=self.root)
            return

        if not self.var_mob.get().isdigit() :
            messagebox.showerror("Error", "Mobile Number must be digits!", parent=self.root)
            return

        email_pattern = r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.com$'
        if not re.match(email_pattern, self.var_email.get()):
            messagebox.showerror("Error", "Invalid email format! Use e.g. user@example.com", parent=self.root)
            return

        try:
            datetime.strptime(self.var_dob.get(), "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Error", "DOB must be in format YYYY-MM-DD", parent=self.root)
            return

        try:
            Update = messagebox.askyesno("Update", "Do you want to update this Student's details?", parent=self.root)
            if not Update:
                return

            file_path = "students.csv"
            if not os.path.exists(file_path):
                messagebox.showerror("Error", "No student data found!", parent=self.root)
                return

            updated = False
            rows = []

            
            with open(file_path, mode='r', newline='') as file:
                reader = csv.reader(file)
                header = next(reader)
                for row in reader:
                    if row[0] != self.var_std_id.get():
                        if row[11] == self.var_roll.get():
                            messagebox.showerror("Error", "Roll Number already used by another student!", parent=self.root)
                            return
                        if row[9] == self.var_mob.get():
                            messagebox.showerror("Error", "Mobile Number already used by another student!", parent=self.root)
                            return
                        if row[12] == self.var_email.get():
                            messagebox.showerror("Error", "Email already used by another student!", parent=self.root)
                            return

           
            with open(file_path, mode='r', newline='') as file:
                reader = csv.reader(file)
                header = next(reader)
                for row in reader:
                    if row[0] == self.var_std_id.get():
                        row = [
                            self.var_std_id.get(),
                            self.var_std_name.get(),
                            self.var_dep.get(),
                            self.var_course.get(),
                            self.var_year.get(),
                            self.var_semester.get(),
                            self.var_div.get(),
                            self.var_gender.get(),
                            self.var_dob.get(),
                            self.var_mob.get(),
                            self.var_address.get(),
                            self.var_roll.get(),
                            self.var_email.get(),
                            self.var_teacher.get(),
                            self.var_radio1.get()
                        ]
                        updated = True
                    rows.append(row)

            if not updated:
                messagebox.showerror("Error", "Student ID not found!", parent=self.root)
                return

            with open(file_path, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(header)
                writer.writerows(rows)

            self.fetch_data()
            messagebox.showinfo("Success", "Successfully Updated!", parent=self.root)

        except Exception as es:
            messagebox.showerror("Error", f"Due to: {str(es)}", parent=self.root)


    
    #==============================Delete Function=========================================

    def delete_data(self):
        if self.var_std_id.get() == "":
            messagebox.showerror("Error", "Student ID Must be Required!", parent=self.root)
            return

        try:
            delete = messagebox.askyesno("Delete", "Do you want to delete this student?", parent=self.root)
            if not delete:
                return

            file_path = "students.csv"
            if not os.path.exists(file_path):
                messagebox.showerror("Error", "No student data file found!", parent=self.root)
                return

            deleted = False
            rows = []

            with open(file_path, mode='r', newline='') as file:
                reader = csv.reader(file)
                header = next(reader)
                for row in reader:
                    if row[0] != self.var_std_id.get():
                        rows.append(row)
                    else:
                        deleted = True

            if not deleted:
                messagebox.showerror("Error", "Student ID not found!", parent=self.root)
                return

            with open(file_path, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(header)
                writer.writerows(rows)

            self.fetch_data()
            messagebox.showinfo("Delete", "Successfully Deleted!", parent=self.root)

        except Exception as es:
            messagebox.showerror("Error", f"Due to: {str(es)}", parent=self.root)

    # Reset Function 
    def reset_data(self):
        self.var_std_id.set(""),
        self.var_std_name.set(""),
        self.var_dep.set("Select Department"),
        self.var_course.set("Select Course"),
        self.var_year.set("Select Year"),
        self.var_semester.set("Select Semester"),
        self.var_div.set("Morning"),
        self.var_gender.set("Male"),
        self.var_dob.set(""),
        self.var_mob.set(""),
        self.var_address.set(""),
        self.var_roll.set(""),
        self.var_email.set(""),
        self.var_teacher.set(""),
        self.var_radio1.set("")
    
    # ===========================Search Data===================


    def search_data(self):
   
        field_mapping = {
            "Student_ID": "Student_ID",
            "Name": "Name",
            "Roll Number": "Roll_No"
        }

      
        selected_field = self.var_searchTX.get().strip()
        search_value = self.var_search.get().strip()

        if selected_field == "Select" or search_value == "":
            messagebox.showerror("Error", "Select combo option and enter search text", parent=self.root)
            return

      
        csv_field = field_mapping.get(selected_field)
        if not csv_field:
            messagebox.showerror("Error", f"Invalid search field: {selected_field}", parent=self.root)
            return

        try:
            file_path = "students.csv"
            if not os.path.exists(file_path):
                messagebox.showerror("Error", "students.csv file not found", parent=self.root)
                return

            with open(file_path, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                found_rows = [list(row.values()) for row in reader if row.get(csv_field, "").strip() == search_value]

            self.student_table.delete(*self.student_table.get_children())
            if found_rows:
                for row in found_rows:
                    self.student_table.insert("", END, values=row)
            else:
                messagebox.showinfo("Not Found", "No matching data found.", parent=self.root)

        except Exception as es:
            messagebox.showerror("Error", f"Due to: {str(es)}", parent=self.root)




#=====================This part is related to Opencv Camera part=======================
# ==================================Generate Data set take image=========================
  
    
    def generate_dataset(self):
        
        fields = [
            self.var_dep.get(), self.var_course.get(), self.var_year.get(),
            self.var_semester.get(), self.var_std_id.get(), self.var_std_name.get(),
            self.var_div.get(), self.var_roll.get(), self.var_gender.get(),
            self.var_dob.get(), self.var_email.get(), self.var_mob.get(),
            self.var_address.get(), self.var_teacher.get()
        ]
        if "" in fields or "Select Department" in fields or "Select Course" in fields or "Select Year" in fields or "Select Semester" in fields:
            messagebox.showerror("Error", "Please fill all fields!", parent=self.root)
            return

        if not self.var_std_id.get().isdigit() or not self.var_roll.get().isdigit() or not self.var_mob.get().isdigit():
            messagebox.showerror("Error", "Student ID, Roll, and Mobile must be digits!", parent=self.root)
            return

        if not re.match(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.com$', self.var_email.get()):
            messagebox.showerror("Error", "Invalid email format!", parent=self.root)
            return

        try:
            datetime.strptime(self.var_dob.get(), "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Error", "DOB must be in format YYYY-MM-DD", parent=self.root)
            return

     
        student_id = self.var_std_id.get()
        student_name = self.var_std_name.get()
        photo_sample = "Yes"
        file_path = "students.csv"
        headers = ["Student_ID", "Name", "Department", "Course", "Year", "Semester", "Division", "Gender", "DOB",
                "Mobile_No", "Address", "Roll_No", "Email", "Teacher_Name", "PhotoSample"]

        data_rows = []
        updated = False

        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                existing_headers = next(reader)
                for row in reader:
                    if row[0] != student_id:
                        if row[11] == self.var_roll.get():
                            messagebox.showerror("Error", "Roll Number already used!", parent=self.root)
                            return
                        if row[9] == self.var_mob.get():
                            messagebox.showerror("Error", "Mobile Number already used!", parent=self.root)
                            return
                        if row[12] == self.var_email.get():
                            messagebox.showerror("Error", "Email already used!", parent=self.root)
                            return
                    if row[0] == student_id:
                        updated = True
                        data_rows.append([
                            student_id, student_name, self.var_dep.get(), self.var_course.get(),
                            self.var_year.get(), self.var_semester.get(), self.var_div.get(), self.var_gender.get(),
                            self.var_dob.get(), self.var_mob.get(), self.var_address.get(), self.var_roll.get(),
                            self.var_email.get(), self.var_teacher.get(), photo_sample
                        ])
                    else:
                        data_rows.append(row)

        if not updated:
            data_rows.append([
                student_id, student_name, self.var_dep.get(), self.var_course.get(),
                self.var_year.get(), self.var_semester.get(), self.var_div.get(), self.var_gender.get(),
                self.var_dob.get(), self.var_mob.get(), self.var_address.get(), self.var_roll.get(),
                self.var_email.get(), self.var_teacher.get(), photo_sample
            ])

        with open(file_path, 'w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(data_rows)

        def face_cropped_mediapipe(img, face_detection):
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            results = face_detection.process(img_rgb)
            if results.detections:
                for detection in results.detections:
                    bboxC = detection.location_data.relative_bounding_box
                    ih, iw, _ = img.shape
                    x = int(bboxC.xmin * iw)
                    y = int(bboxC.ymin * ih)
                    w = int(bboxC.width * iw)
                    h = int(bboxC.height * ih)
                    face = img[max(0, y):y + h, max(0, x):x + w]
                    if face.shape[0] > 100 and face.shape[1] > 100:
                        return face
            return None

        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            messagebox.showerror("Error", "فشل في فتح الكاميرا", parent=self.root)
            return

        img_id = 0
        student_folder = "data_img"
        os.makedirs(student_folder, exist_ok=True)

        with mp.solutions.face_detection.FaceDetection(model_selection=1, min_detection_confidence=0.6) as face_detection:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                face = face_cropped_mediapipe(frame, face_detection)
                if face is not None:
                    img_id += 1
                    face_gray = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
                    face_resized = cv2.resize(face_gray, (450, 450))
                    file_path = os.path.join(student_folder, f"{student_id}_{img_id}.jpg")
                    cv2.imwrite(file_path, face_resized)
                    cv2.waitKey(50)
                    
                    cv2.putText(frame, f"Image {img_id}/150", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                    cv2.putText(frame, "Move your head: Left, Right, Up, Down", (10, 60),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
                    cv2.imshow("Capturing Face", frame)

                if cv2.waitKey(1) & 0xFF == 27 or img_id >= 150:
                    break

        cap.release()
        cv2.destroyAllWindows()
        messagebox.showinfo("Result", "Dataset Generation Completed!", parent=self.root)
        self.fetch_data()
        self.reset_data()



# main class object

if __name__ == "__main__":
    root=Tk()
    obj=Student(root)
    root.mainloop()
