import pickle
import face_recognition
from sys import path
from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
import os
import cv2
import numpy as np
from tkinter import messagebox
import mediapipe as mp


# مهم جدًا لحل مشكلة الـ DLL في OpenCV
os.add_dll_directory(os.path.dirname(cv2.__file__))

class Train:

    def __init__(self,root):
        self.root=root
        self.root.geometry("1366x768+0+0")
        self.root.title("Train Pannel")

        # This part is image labels setting start 
        # first header image  
        # الحصول على أبعاد الشاشة تلقائيًا
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # تحميل وتعديل حجم صورة البانر لتناسب عرض الشاشة
        img = Image.open(os.path.join(os.path.dirname(__file__), "Images_GUI/banner.jpg"))
        banner_height = int(screen_height * 0.15)  # 15% من الشاشة
        img = img.resize((screen_width, banner_height), Image.Resampling.LANCZOS)
        self.photoimg = ImageTk.PhotoImage(img)

        # تعيين صورة البانر
        f_lb1 = Label(self.root, image=self.photoimg)
        f_lb1.place(x=0, y=0, width=screen_width, height=banner_height)

        # تحميل وتعديل صورة الخلفية لتناسب كل الشاشة
        bg1 = Image.open(os.path.join(os.path.dirname(__file__), "Images_GUI/t_bg1.jpg"))
        bg1 = bg1.resize((screen_width, screen_height), Image.Resampling.LANCZOS)
        self.photobg1 = ImageTk.PhotoImage(bg1)

        # تعيين صورة الخلفية
        bg_img = Label(self.root, image=self.photobg1)
        bg_img.place(x=0, y=banner_height, width=screen_width, height=screen_height - banner_height)



        #title section
        title_lb1 = Label(bg_img,text="Welcome to Training Pannel",font=("verdana",30,"bold"),bg="white",fg="navyblue")
        title_lb1.place(relx=0, rely=0, relwidth=1, relheight=0.06)


        # Create buttons below the section 
        # ------------------------------------------------------------------------------------------------------------------- 
        # Training button 1
        std_img_btn=Image.open(os.path.join(os.path.dirname(__file__),"Images_GUI/t_btn1.png"))
        std_img_btn=std_img_btn.resize((180,180),Image.Resampling.LANCZOS)
        self.std_img1=ImageTk.PhotoImage(std_img_btn)

        std_b1 = Button(bg_img,command=self.train_classifier,image=self.std_img1,cursor="hand2")
        std_b1.place(x=600,y=170,width=180,height=180)

        std_b1_1 = Button(bg_img,command=self.train_classifier,text="Train Dataset",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        std_b1_1.place(x=600,y=350,width=180,height=45)

    # ==================Create Function of Traing===================
   
   
    def train_classifier(self):
        data_dir = "data_img"
        path_list = [os.path.join(data_dir, file) for file in os.listdir(data_dir) if file.endswith(".jpg")]

        faces = []
        ids = []

        for path in path_list:
            img = Image.open(path).convert('L')  # ✅ تحويل الصورة إلى رمادي
            image_np = np.array(img, 'uint8')

            filename = os.path.basename(path)
            try:
                student_id = int(filename.split('_')[0])  # ✅ استخراج ID من اسم الصورة
            except ValueError:
                print(f"⚠️ تم تخطي ملف غير صالح: {filename}")
                continue

            faces.append(image_np)
            ids.append(student_id)

        if len(faces) == 0:
            messagebox.showwarning("Warning", "لا توجد صور تدريبية في مجلد data_img", parent=self.root)
            return

        ids = np.array(ids)

        # ✅ تدريب النموذج وحفظه
        clf = cv2.face.LBPHFaceRecognizer_create()
        clf.train(faces, ids)
        clf.save("clf.xml")

        messagebox.showinfo("Result", "✅ Training completed and saved as clf.xml", parent=self.root)

  



if __name__ == "__main__":
    root=Tk()
    obj=Train(root)
    root.mainloop()